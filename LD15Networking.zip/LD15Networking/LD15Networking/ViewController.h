//
//  ViewController.h
//  LD15Networking
//
//  Created by larry on 12/3/14.
//  Copyright (c) 2014 Larry Kerschner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@property (weak, nonatomic) IBOutlet UIProgressView *progressView;


@end

